import { Injectable } from '@angular/core';
import { RouterModule , Router} from '@angular/router';
import { HttpClient } from '@angular/common/http';

import { UserProfile } from '../shared/UserProfile.model';

@Injectable({
  providedIn: 'root'
})
export class UserProfileService {

  selectedUser: UserProfile;
  userProfile: UserProfile[];
  currentUser = [];
  loggedInUser ;
  i;
  hideLogin = false;
  readonly baseURL = 'http://localhost:3000/userprofiles';

  constructor(private http: HttpClient, private router: Router) { }

  currentUserData(loginForm) {
    this.currentUser.push(loginForm);
    console.log('Current User : ', this.currentUser);
    console.log('DB Users : ', this.userProfile);
    for ( this.i = 0; this.i < this.userProfile.length; this.i++) {
      if (this.currentUser[0].username === this.userProfile[this.i].username) {
        if (this.currentUser[0].password === this.userProfile[this.i].password) {
          this.loggedInUser = this.userProfile[this.i];
          console.log('Success : ', this.loggedInUser);
          this.router.navigateByUrl('home');
          this.hideLogin = true;
        } else {
          console.log('error for', this.userProfile[this.i].password);
          this.currentUser = [];
        }
      } else {
        console.log('error for', this.userProfile[this.i].username);
        this.currentUser = [];
      }
    }
    console.log('all time : ', this.loggedInUser);
  }



  postEmployee(user: UserProfile) {
    return this.http.post(this.baseURL, user);
  }

  getEmployeeList() {
    return this.http.get(this.baseURL);
  }

  putEmployee(user: UserProfile) {
    return this.http.put(this.baseURL + `/${user._id}`, user);
  }

  deleteEmployee(_id: string) {
    return this.http.delete(this.baseURL + `/${_id}`);
  }
}
