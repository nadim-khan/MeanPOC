export class UserProfile {
    // tslint:disable-next-line:ban-types
    _id: String;
    firstname: string;
    lastname: string;
    username: string;
    profileimage: string;
    email: string;
    password: number;
  }
