import { Component, OnInit } from '@angular/core';
import { FormsModule, FormBuilder, Validators } from '@angular/forms';

import { UserProfileService } from '../shared/user-profile.service';
import { UserProfile } from '../shared/UserProfile.model';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor( private fb: FormBuilder, private profileService: UserProfileService) { }
  loginForm = this.fb.group({
    username: ['', Validators.required],
    password: ['', Validators.required],
  });

  ngOnInit() {
    this.profileService.getEmployeeList().subscribe((res) => {
      this.profileService.userProfile = res as UserProfile[];
    });
  }

  onLogin() {
    this.profileService.currentUserData(this.loginForm.value);
  }
}
