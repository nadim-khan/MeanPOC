import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-system-configuration',
  templateUrl: './system-configuration.component.html',
  styleUrls: ['./system-configuration.component.css']
})
export class SystemConfigurationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
