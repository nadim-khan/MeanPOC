import { Injectable } from '@angular/core';
import { RouterModule , Router} from '@angular/router';
import { HttpClient } from '@angular/common/http';

import { UserRole } from './UserRole.model';

@Injectable({
  providedIn: 'root'
})
export class UserRoleService {

  selectedUser: UserRole;
  userProfile: UserRole[];
  readonly baseURL = 'http://localhost:3000/userroles';

  constructor(private http: HttpClient, private router: Router) { }

  postRole(user: UserRole) {
    return this.http.post(this.baseURL, user);
  }

  getRoleList() {
    return this.http.get(this.baseURL);
  }

  putRole(user: UserRole) {
    return this.http.put(this.baseURL + `/${user._id}`, user);
  }

  deleteRole(_id: string) {
    return this.http.delete(this.baseURL + `/${_id}`);
  }
}
