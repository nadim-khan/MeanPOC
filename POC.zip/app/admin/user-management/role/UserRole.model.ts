export class UserRole {
    // tslint:disable-next-line:ban-types
    _id: String;
    // tslint:disable-next-line:variable-name
    role_name: string;
    // tslint:disable-next-line:variable-name
    sys_role: string;
    // tslint:disable-next-line:variable-name
    role_desc: string;
    // tslint:disable-next-line:variable-name
    role_c_date: Date;
    // tslint:disable-next-line:variable-name
    role_u_date: Date;
  }
