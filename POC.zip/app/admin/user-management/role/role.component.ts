import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormBuilder, FormArray, Validators  } from '@angular/forms';

import { UserRoleService } from './user-role.service';
import { UserRole } from './UserRole.model';

@Component({
  selector: 'app-role',
  templateUrl: './role.component.html',
  styleUrls: ['./role.component.css']
})
export class RoleComponent implements OnInit {
  constructor( private fb: FormBuilder , private roleService: UserRoleService) { }
  selData;
  createRole = this.fb.group({
    sys_role: ['', Validators.required],
    role_name: ['', Validators.required],
    role_desc: ['', Validators.required],
  });
  editRole = this.fb.group({
    sys_role: ['', Validators.required],
    role_name: ['', Validators.required],
    role_desc: ['', Validators.required],
  });

  public selectedRow(event, u) {
    this.selData = this.createRole.value;
    console.log('Selected Data : ' + JSON.stringify(this.selData));
   }

  onCreateRole(createRole) {
    console.log('Role Created : ', createRole.value);
    createRole.reset();
    this.refreshList();
  }
  onUpdateRole(editRole) {
    console.log('Role Updated : ', editRole.value);
    editRole.reset();
    this.refreshList();
  }

  ngOnInit() {
    this.refreshList();
  }
  refreshList() {
    this.roleService.getRoleList().subscribe((res) => {
      this.roleService.userProfile = res as UserRole[];
    });
  }

}
