import { Component, OnInit } from '@angular/core';
import { FormsModule, FormBuilder, Validators, NgForm } from '@angular/forms';

import { UserProfileService } from 'src/app/shared/user-profile.service';
import { UserProfile } from 'src/app/shared/UserProfile.model';

declare var M: any;

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  showForm = false;
  constructor(private fb: FormBuilder, public profileService: UserProfileService) {
  }
  registerForm = this.fb.group({
    _id: [''],
    firstname: ['', Validators.required],
    lastname: ['', Validators.required],
    username: ['', Validators.required],
    profileimage: ['', Validators.required],
    email: ['', Validators.required],
    password: ['', Validators.required],
  });

  ngOnInit() {
    this.refreshUserList();
  }
  refreshUserList() {
    this.profileService.getEmployeeList().subscribe((res) => {
      this.profileService.userProfile = res as UserProfile[];
    });
  }
  registerView() {
    this.showForm = true;
  }
  ListView() {
    this.showForm = false;
  }
  resetForm(registerForm) {
  }


  onSubmit(registerForm) {
    if (registerForm.value._id === '') {
      this.profileService.postEmployee(registerForm.value).subscribe((res) => {
        console.log(res);
        alert('Data Saved Succesfully !');
        this.refreshUserList();
        this.showForm = false;
      });
    } else {
      alert('error');
    }
  }

  onDelete(_id: string, registerForm) {
    if (confirm('Are you sure to delete this record ?') === true) {
      this.profileService.deleteEmployee(_id).subscribe((res) => {
        this.resetForm(registerForm);
        alert('Successfully deleted');
        this.refreshUserList();
      });
    }
  }

}
