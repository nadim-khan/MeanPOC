import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-workflow-config',
  templateUrl: './workflow-config.component.html',
})
export class WorkflowConfigComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
