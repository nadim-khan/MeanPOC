import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app-auth',
  templateUrl: './app-auth.component.html',
})
export class AppAuthComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
