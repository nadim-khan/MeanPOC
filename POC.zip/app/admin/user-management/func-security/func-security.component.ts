import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-func-security',
  templateUrl: './func-security.component.html',
})
export class FuncSecurityComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
