import { Component, OnInit, OnChanges } from '@angular/core';
import { Router } from '@angular/router';

import { UserProfileService } from '../shared/user-profile.service';
import { UserProfile } from '../shared/UserProfile.model';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {
  loggedUser;
  constructor(private router: Router, private profileService: UserProfileService) {
    this.loggedUser = this.profileService.loggedInUser;
    console.log(this.loggedUser);
   }

  ngOnInit() {
    this.profileService.getEmployeeList().subscribe((res) => {
      this.profileService.userProfile = res as UserProfile[];
    });
  }
  // tslint:disable-next-line:use-lifecycle-interface
  onLoad() {
    this.loggedUser = this.profileService.loggedInUser;
  }

}
